package com.sakshi.journalApp.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

    @Component
    public class JwtUtil {
        @Value("${jwt.secret}")
        private String secretString;
        private SecretKey getSigningKey() {
            return Keys.hmacShaKeyFor(secretString.getBytes());
        }

        public String extractUsername(String token) {
            Claims claims = extractAllClaims(token);
            return claims.getSubject();
        }

        public Date extractExpiration(String token) {
            return extractAllClaims(token).getExpiration();
        }

        private Claims extractAllClaims(String token) {
            return Jwts.parser()
                    .verifyWith(getSigningKey())
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
        }

        private Boolean isTokenExpired(String token) {
            return extractExpiration(token).before(new Date());
        }

        public String generateToken(String username) {
            Map<String, Object> claims = new HashMap<>();
            return createToken(claims, username);
        }

        private String createToken(Map<String, Object> claims, String subject) {
            return Jwts.builder()
                    .claims(claims)
                    .subject(subject)
                    .header().empty().add("typ","JWT")
                    .and()
                    .issuedAt(new Date(System.currentTimeMillis()))
                    .expiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60)) // 1 hour expiration time
                    .signWith(getSigningKey())
                    .compact();
        }

        public Boolean validateToken(String token) {
            return !isTokenExpired(token);
        }


    }
